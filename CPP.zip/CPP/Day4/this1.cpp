// #include<iostream>
// using namespace std;
// class test
// {
// 	int a,b;
// 	public:
// 	void show()
// 	{
// 		a=10;
// 		b=20;
// 	cout<<"obj add"<<this<<endl;//print current class obj adddress (1000)
// 	//cout<<"a" <<this->a<<endl;
//     cout<<"a" <<a<<endl;
// 	cout<<"b"<<this->b<<endl;//cout<<"b"<<b<<endl;
// }
// };
// int main()
// {
// 	test t;
// 	cout<<&t<<endl;//1000(object's address) assume this=1000
// 	t.show();//implicitly this pointer will be passed to show()
// }


#include<iostream>
using namespace std;
class date
{
	int dd,mm,yy;
	public:
	void show();
	date(int,int,int);
	date();
};
date::date()
{
	this->dd=this->mm=this->yy=0;
}
 date::date(int dd,int mm,int yy)
{
	this->dd=dd;
	this->mm=mm;
	this->yy=yy;
}
 void date::show()
 {
	 cout<<"date is "<<this->dd<<"/"<<this->mm<<"/"<<yy<<endl;
 }
 int main()
{
	date d1(1,1,1);
	d1.show();
	date d2(2,2,2);
	d2.show();
}
