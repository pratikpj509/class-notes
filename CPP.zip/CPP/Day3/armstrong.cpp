#include<iostream>
using namespace std;
int main(){
    int num,rem,ans=0,n;
    cout<<"enter a number"<<endl;
    cin>>num;
    n=num;
    while(num!=0){
        rem=num%10;
        ans=ans+rem*rem*rem;
        num=num/10;
    }
    if(n==ans){
        cout<<"Given number is armstrong"<<endl;
    }
    else{
        cout<<"Given number is not an armstrong"<<endl;
    }
}