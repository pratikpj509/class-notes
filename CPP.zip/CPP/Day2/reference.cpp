#include<iostream>
using namespace std;
//void swap(int&,int&);
void add(int,int);
int main(){
  int a,b;
  cout<<"enter the value of a and b"<<endl;
  cin>>a>>b;
  swap(a,b);
  add(a,b);
  cout<<"after swapping values of a and b are "<<a<<"\t"<<b<<endl;
}
void swap(int &p,int &q){
    int temp=p;
    p=q;
    q=temp;
    cout<<"after swapping values of p and q are "<<p<<"\t"<<q<<endl;
}
void add(int p,int q){
    int ans=p+q;
    cout<<ans<<endl;
}