#include<iostream>
using namespace std;
//call by value
void swap(int,int);
void swap1(int*, int*);
int main(){
    int a,b;
    cout<<"Enter the values of a and b"<<endl;
    cin>>a>>b;
    cout<<"before swapping values of a and b are"<<a<<"\t"<<b<<endl;
    //call by value
    swap(a,b);
    cout<<"after swapping values of a and b are "<<a<<"\t"<<b<<endl;
    //call by address
    swap1(&a,&b);
    cout<<"after swapping values of a and b are "<<a<<"\t"<<b<<endl;
}
//call by value
void swap(int p,int q){
    int temp;
    temp=p;
    p=q;
    q=temp;
    cout<<"after swapping values of p and q are "<<p<<"\t"<<q<<endl;
}
//call by address
void swap1(int *p,int *q){
    int temp=*p;
    *p=*q;
    *q=temp;
    cout<<"after swapping values of p and q are "<<*p<<"\t"<<*q<<endl;

}
