#include<iostream>
using namespace std;
int main(){
    const int b=1;
    


}