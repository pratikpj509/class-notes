#include<iostream>
using namespace std;
class ABC  
{   
     int b=6;
     public:
        const int A=5;  

void fun () const   
{   //b=7;
   cout<<b<<endl;
   //A = 6; // it shows compile time error  
}  
};  
  
int main ()  
{  
    const ABC obj ;  
    obj.fun();  
    return 0;  
} 
