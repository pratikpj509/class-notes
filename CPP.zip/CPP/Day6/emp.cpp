#include<iostream> 
using namespace std; 
class employee
{  int id;
    public:
    employee();
    employee(int);
    void display();
    int findsalary(){
        return 0;
    }  
};
employee::employee(){
    cout<<"default constructor of emp\n";
    id=0;
}
employee::employee(int i){
    cout<<"in para emp"<<endl;
    id=i;
}
void employee::display(){
    cout<<"id of an employee is"<<id<<endl;
}
class wageemployee:public employee{
    int hrs,rate;
    public:
    wageemployee();
    wageemployee(int,int,int);
    void display();
    int findsalary(){
        return hrs*rate;
    }

};
wageemployee::wageemployee(){
    cout<<"default cons of wageemployee"<<endl;
    hrs=rate=0;
}
wageemployee::wageemployee(int i,int h,int r):employee(i){
    hrs=h;
    rate=r;
}
void wageemployee::display(){
  employee::display();
  cout<<"hrs of an emp is"<<hrs<<endl;
  cout<<"rate of an emp is"<<rate<<endl;
}
class salesperson:public wageemployee{
    int sales,comm;
    public:
    salesperson();
    salesperson(int,int,int,int,int);
    void display();
    int findsalary(){
        return wageemployee::findsalary()+sales*comm;
    };

};
salesperson::salesperson(){
    cout<<"default cons of salesperson"<<endl;
    sales=comm=0;
}
salesperson::salesperson(int i,int h,int r,int s,int c):wageemployee(i,h,r){
    cout<<"in para constructor of salesperson";
    sales=s;
    comm=c;
}
void salesperson::display(){
    wageemployee::display();

cout<<"sales of an eemp is "<<sales<<endl;
cout<<"comm of an eemp is "<<comm<<endl;
}
int main(){
    // wageemployee w1(1,5,100);
    // w1.display();
    // cout<<"salary is"<<w1.findsalary();


    // wageemployee * ptr=new wageemployee(1,5,1000);
	// ptr->display();
	// delete ptr;
   // ptr->display();

   salesperson sp1(1,5,1000,100000,1);
	sp1.display();
}