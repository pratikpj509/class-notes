#include<iostream>
using namespace std;
void str_copy(char*,char*);
int main(){
    char str1[10];
    char str2[10];
    cout<<"Enter a string"<<endl;
    cin>>str1;
    
    str_copy(str1,str2);
    cout<<"copied string is:"<<str2;
}
void str_copy(char* s1,char* s2){
    while(*s1!='\0'){
        *s2=*s1;
        s1++;
        s2++;
        
    }
    *s2='\0';
}