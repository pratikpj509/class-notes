// #include<iostream>
// using namespace std;
// int main(){
//     char str[20];
//     cout<<"enter a string"<<endl;
//     cin>>str;
//     while(str!='\0'){
//         cout<<str;
//     }

// }
#include<iostream>
using namespace std;

int main(){
    char str[20];
    cout << "Enter a string" << endl;
    cin >> str;

    int i = 0;
    while(str[i] != '\0'){
        cout << str[i];
        i++;
    }
}
