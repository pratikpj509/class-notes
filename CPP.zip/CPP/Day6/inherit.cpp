#include<iostream>
using namespace std;
class A
{
	int c=10;
public:
//int c;
	int a=7;
protected:
	int b=9;
public:
	void display()
	{
		cout<<"in display of A\n";
	}
};
class B:private A
{
public:
	int c=9;

	void show()
	{
	    display();//allowed
		cout<<a<<b;
	}
};
class C:private B
{
	public:
	void show()
	{
	   // display(); not allowed
		//cout<< a<<b; not allowed
		cout<<c;
	}
};
int main()
{
	B bobj;
	bobj.show();
//	bobj.display(); not allowed
}