#include<iostream>
using namespace std;
int main(){
    int f,ans=1,num;
    cout<<"Enter a number"<<endl;
    cin>>num;
    for(int i=1;i<=num;i++){
        ans=ans*i;
    }
    cout<<"factorial of a given number= "<<ans;
}