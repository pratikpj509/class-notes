#include<iostream>
using namespace std;
class Cdate{
    int dd, mm, yy;
    public:
        Cdate();
        Cdate(int);
        void accept();
        void display() const;
        void setDate(int);
        int getDate() const;

};
Cdate::Cdate(){
    cout<<"Hello"<<endl;
}
Cdate::Cdate(int n){
    dd=n;
}
void Cdate:: accept(){
    cout<<"Enter a date"<<endl;
    cin>>dd>>mm>>yy;
}
void Cdate::display() const{
    cout<<"todays date : "<<dd<<"/"<<mm<<"/"<<yy<<endl;
}
void Cdate:: setDate(int d) {
    dd=d;

}
int Cdate:: getDate () const{
    return dd;
}

int main(){
    Cdate c1;
    const Cdate c2(8);
    c1.accept();
    c1.display();
    c1.setDate(5);
    cout<<"updated date is : "<<c1.getDate();
     cout<<"updated date is : "<<c2.getDate();


}