#include<iostream>
using namespace std;
int main(){
    int num,count=0;
    cout<<"Enter the number"<<endl;
    cin>>num;
    for(int i=2;i<num-1;i++){
        if(num%i==0){
            count++;
            cout<<"Given number is not prime"<<endl;
            break;
        }

    }
    if(count==0){
        cout<<"Given number is prime number"<<endl;
    }

}