#include<iostream>
using namespace std;
#include<string.h>
int n;
int main(){
   char str[20];
   cout<<"Enter a String"<<endl;
   cin>>str;
   int start=0;
   int end=strlen(str)-1;
   while(start<end){
     swap(str[start],str[end]);
     start++;
     end--;
   }
   cout<<"Reverse string: "<<str;     
}
  