// #include<iostream>
// using namespace std;
// void add(int=10,int=20,int=30);
// int main(){
//    add();
//    add(2,3);
//    add(5,6,7);
//  }
// void add(int a,int b,int c){
//    cout<<a+b+c<<endl;
// }



// #include<iostream>
// using namespace std;
// void func(int a, bool flag = true)
// {
// 		if (flag == true ) 
// 		{
// 			cout<< "Flag is true. a = " << a;
//       	        }
// 		else
// 		{
// 			cout<< "Flag is false. a = " << a;
//         	}
// }
// int main()
// {
// 	func(200, false);
// }


#include<iostream>
using namespace std;
void display1(int, int=5);
void display(int=1,int=2);
void display3(int,int);
int main(){
   display();//1+2//3
   display1(3);//8//
   display3(4,3);//7
}
void display(int a,int b){
    cout<<a+b<<endl;
}
void display1(int a,int b){
    cout<<a+b<<endl;
}
void display3(int a,int b){
    cout<<a+b<<endl;
}