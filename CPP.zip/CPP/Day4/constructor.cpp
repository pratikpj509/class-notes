#include<iostream>
using namespace std;
class A{
    public:
    int sum;
    A(int a,int x=0){
        sum=a+x;
    }
    void display(){
    cout<<"sum is "<<sum<<endl;
    }
    
};
int main(){
A a1(3,4);//7
A a2(4);//4
a1.display();
a2.display();
}

