#include <iostream>
using namespace std;
int main()
{
    int n, num,rem, rev = 0;
    cout << "Enter a positive number: ";
    cin >> num;
    n = num;
    while(num!=0){
       rem=num%10;
       rev=rev*10+rem;
       num=num/10;
    }
    if(rev==n){
        cout<<"Given number is palindrome"<<endl;
    }
    else{
        cout<<"Given number is not a palindrome"<<endl;
    }
}