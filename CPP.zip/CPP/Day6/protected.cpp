#include<iostream>
using namespace std;
class employe{
    protected: int x=2;
    public:
        void display(){
            cout<<"in employe";
        }
};
class student: public employe{

    public:
    void empname(){
        cout<<"in student"<<" "<<x;
    }
} ;
int main(){

    student s;
    s.empname();
}