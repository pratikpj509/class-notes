#include<iostream>
using namespace std;
int main(){
    int a[2];
    cout<<"Enter the values"<<endl;
    for(int i=0; i<2;i++){
        cin>>a[i];
    }
    
    for(int i=0;i<2;i++){
        cout<<a[i]<<"\t";

    }

    //by Pointer
    cout<<endl;
    cout<<"Enter the values "<<endl;
    for(int i=0;i<2;i++){
        cin>>*(a+i);
    }
    for(int i=0;i<2;i++){
        cout<<*(a+i)<<"\t";
    }




}