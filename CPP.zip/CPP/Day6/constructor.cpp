#include<iostream>
using namespace std;
class A{
    public:
    A(){
        cout<<"A constructor called"<<endl;

    }
    A(int a){
        cout<<"A parameterized constructor call: "<<a<<endl;
    }
};
class B:public A{
    public:
    B(){
        cout<<"B constructor called"<<endl;
    }
    B(int b,int c):A(8){
        cout<<"B parameterized constructor called: "<<b<<c<<endl;
    }
};
int main(){
    B obj(5,6);
}