#include<iostream>
using namespace std;
int main(){
    char c,d;
    cout<<"enter two characters"<<endl;
    cin>>c>>d;
    int ans=c+d;
    cout<<ans;
}