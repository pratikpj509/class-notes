#include<iostream>
using namespace std;
int main(){
int n,m;
cout<<"enter the number"<<endl;
cin>>n;
cout<<"enter power of a number"<<endl;
cin>>m;
int ans=1;
for(int i=1;i<=m;i++){
    ans=ans*n;
}
cout<<"power of a " <<n<<  "is: "<<ans;
}