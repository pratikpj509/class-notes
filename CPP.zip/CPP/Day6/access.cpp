#include<iostream>
using namespace std;
class parent{
    int pvt=5;
    public:
    int pub=7;
    public:
    int prot=8;
    void getpvt(){
        cout<<pvt<<endl;
    }
};
class child:protected parent{
    //int c=45;
    public:
    void getprot(){
        cout<<prot<<endl;
    }     
    void getpub(){
        cout<<pub<<endl;
    }
   
};
class child2:public child{
    public:
    void get(){
        cout<<prot<<endl;
    }

};

int main(){
    //child2 c1;
   // c1.get();
    //c1.getpvt()
   //c1.getprot();
    //c1.getpub();
    child c1;
    c1.getprot();
   // c1.getpvt();
   c1.getpub();
   c1.getprot();

}