#include<iostream>
using namespace std;
void show();
int x=10;   //global variable

int main(){
    cout<<x<<endl;
    x++;
    x=12;
    show();
    cout<<x<<endl;
}
void show(){
    cout<<x<<endl;
    int y=0;  //local variable
    cout<<y<<endl;
    y++;
    cout<<y<<endl;
}