// Writeastudent class and use it in your program. Store the data of 10 students and display
// the sorted data according to their roll numbers, dates of birth, and total mark
#include <iostream>
#include <string>
using namespace std;

class Student {
public:
    string roll;
    string birth;
    int totalMarks;

    void setData() {
        cout << "Enter roll number: ";
        cin >> roll;
        cout << "Enter date of birth (YYYY-MM-DD): ";
        cin >> birth;
        cout << "Enter total marks: ";
        cin >> totalMarks;
    }

    void getData() {
        cout << "Roll No: " << roll << ", DOB: " << birth << ", Marks: " << totalMarks << endl;
    }
};

void sortByRoll(Student s[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (s[j].roll > s[j + 1].roll) {
                swap(s[j], s[j + 1]);
            }
        }
    }
}

int main() {
    const int SIZE = 3;
    Student s[SIZE];


    for (int i = 0; i < SIZE; i++) {
        cout << "\nStudent " << i + 1 << ":\n";
        s[i].setData();
    }

    // Sort
    sortByRoll(s, SIZE);

    // Output
    cout << "\nSorted by Roll Number:\n";
    for (int i = 0; i < SIZE; i++) {
        s[i].getData();
    }

    return 0;
}
