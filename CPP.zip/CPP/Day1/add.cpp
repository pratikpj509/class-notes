#include<iostream>
using namespace std;
int add(int,int);
int main(){
    int a,b;
    cout<<"enter add two numbers"<<endl;
    cin>>a>>b;
    int ans=add(a,b);
    cout<<"sum of two number= "<<ans;
}
int add(int p,int q){
    int sum=p+q;
    return sum;
}