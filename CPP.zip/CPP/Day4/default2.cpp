#include<iostream>
using namespace std;
void display (int=1,int=2,int =3, int=4);
int main(){
    display();
    display(5);
    display(6,7);
    display(8,9,10);
    display(11,12,13,14);
}
void display(int a,int b,int c, int d){
    cout<<a+b+c+d<<endl;

}