#include<iostream>
using namespace std;
int main(){
    int a[5];
    int fmax=-1,smax=-1;
    cout<<"enter elements of array";
    for(int i=0;i<5;i++){
    cin>>a[i];
    }
    for(int i=0;i<5;i++){
        if(fmax<a[i]){
            fmax=a[i];
        }
    }
    for(int i=0;i<5;i++){
       if(a[i]!=fmax && smax<a[i]){
        smax=a[i];
       }
    
    }
    cout<<"first maximum no:"<<fmax<<endl;
    cout<<"second highest: "<<smax;

}