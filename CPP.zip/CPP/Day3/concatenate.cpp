#include<iostream>
using namespace std;

void user_strcat(char*,char*);
int main(){
    char str[20];
    char str1[20];
    cout<<"enter first string \n";
    cin>>str;
    cout<<"enter second string \n";
    cin>>str1;
    user_strcat(str,str1);
    cout<<str; 
}
void user_strcat(char *s1,char* s2){
    while(*s1!='\0')
     s1++;
    while(*s2!='\0'){
     *s1=*s2;
     s1++;
     s2++;
}
*s1='\0';
}