#include<iostream>
using namespace std;
class A{
    public :
    A();
    A(int ,int=2);
};
A::A(){
    cout<<"Hello"<<endl;
}
A::A (int a,int b){
    cout<<a+b<<endl;//5
}
int main(){
    A obj;//****imp/
    A obj1(3);//5
    A obj2(5,6);//11
    
}