#include<iostream>
using namespace std;
class A
{
	int c;
public:
	int a=5;
protected:
	int b=8;
public:
	void display()
	{
		cout<<"in display of A\n";
	}

};
class B:public A
{
public:
		public:
	
	//display(); //cant call function from the class
	void show()
	{
	   display();
		cout<<a<<b;
	}
};
class C:public B
{
	public:
	void show()
	{
		cout<< a<<b;
			}
};
int main()
{
	B bobj;
	bobj.show();
	bobj.display();
}