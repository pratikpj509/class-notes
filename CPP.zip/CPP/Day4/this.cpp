#include<iostream>
using namespace std; 
class test
{
	int a=1,b=2;
public:
void show(int a,int b)
{   cout<<"address stored in this "<<this<<endl;
	this->a=a;
	this->b=b;

}
void display()
{
	cout<<a<<b;
}
};
int main()
{
	test t;
    cout<<&t;
	t.show(10,20);
	t.display();
}