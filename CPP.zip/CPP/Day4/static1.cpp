#include<iostream>
using namespace std;
class Complex{
    int real,img;
     static int cnt;
    public:
    //  static int cnt;
        void show();
        Complex();
        Complex(int ,int );
        static int getCnt();
};
int Complex::cnt;
int Complex::getCnt(){
    return cnt;
}
void Complex::show(){
    cout<<"complex no is"<<real<<"+"<<img<<"i"<<""<<endl;
}
Complex::Complex(){
    cout<<"in default constructor\n";
    real=10;
    img=20;
    cnt++;//1//2
}
Complex::Complex(int r,int i){
    cout<<"Parameterised constructor\n";
    real=r;
    img=i;
    cnt++;//3

}
int main(){
    Complex c1,c2;
    Complex c3(5,6);
    cout<<"no of Objects created is "<<Complex::getCnt()<<endl;
    c3.show();
    cout<<"sizeof obj is "<<sizeof(c1)<<endl;
     cout<<"sizeof obj is "<<sizeof(c2)<<endl;


    //cout<<Complex::cnt;
}
