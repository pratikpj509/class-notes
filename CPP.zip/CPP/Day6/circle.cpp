#include<iostream>
using namespace std;
class Circle{
     double r;
     public:
       void area(int r){
        double ans=3.14*r*r;
        cout<<"area of circle:"<<ans<<endl;
       }
       double circumference(int rr){
        double ans1=2*3.14*rr*rr;
        return ans1;
       }
};
int main(){
Circle c1;
c1.area(2);
// c1.r; //not accessible
int a=c1.circumference(5);
cout<<"circumferece of a circle is: "<<a;
}
