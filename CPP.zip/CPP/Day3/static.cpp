#include<iostream>
using namespace std;
static int x;
void show();
int main(){
   int x=2;
   cout<<"values of x: "<<x<<endl;
   x++;
   cout<<"values of x: "<<x<<endl;
   show();
}
void show(){
    int y=0;
    cout<<"value of y: "<<y<<endl;
    y++;
    cout<<"value of y: "<<y<<endl;
    cout<<"value of x: "<<x<<endl;
}