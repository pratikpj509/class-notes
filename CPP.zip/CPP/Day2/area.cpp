#include<iostream>
using namespace std;
void area (int, int);
int main(){
    int l,b;
    cout<<"Enter l & b "<<endl;
    cin>>l>>b;
    area(l,b);
}
void area(int l,int b){
    int ans=l*b;
    cout<<"area of rectangle is: "<<ans; 
}
